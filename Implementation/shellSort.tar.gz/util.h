/* 
 * File:   util.h
 * Author: paco
 *
 * Created on 5 de junio de 2012, 10:14
 */

#ifndef UTIL_H
#define	UTIL_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* UTIL_H */

